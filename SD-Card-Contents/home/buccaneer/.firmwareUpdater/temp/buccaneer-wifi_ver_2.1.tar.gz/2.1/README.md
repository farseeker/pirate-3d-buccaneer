Run wifiConfig.py for running wifi functionalities


Command						;Description


help						;Print this help menu

connect "wifiName" "passwd"			;Connect to wifi

isConnected					;Check if connected to internet and by which interface

scan						;Scan and give the list of wireless networks

startWifi					;Connects to last connected wifi

stopWifi					;Disconnect to wifi

changeAP -name|-passwd "wifiName|passwd"	;To change wifi name or password of access point

changeAP -name "wifiName" -passwd "passwd"	;To change both wifi name and password of access point


